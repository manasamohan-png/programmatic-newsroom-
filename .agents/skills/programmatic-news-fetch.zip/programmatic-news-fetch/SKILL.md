---
name: programmatic-news-fetch
description: Fetches, deduplicates, and compiles the latest programmatic advertising news articles from Digiday, AdExchanger, eMarketer, Wall Street Journal (CMO Today), and New York Times (Media & Advertising) RSS feeds from the last 7 days.
parameters:
  days:
    type: integer
    description: Number of days of news to fetch (default is 7).
    required: false
  output-dir:
    type: string
    description: Directory to save the generated Markdown and CSV reports (default is current directory).
    required: false
  slack-channel:
    type: string
    description: Optional Slack channel ID or name to send a summary of the report to (e.g. C12345678 or #general).
    required: false
  schedule:
    type: boolean
    description: Schedule this script to run automatically via macOS launchd.
    required: false
  sources:
    type: string
    description: Comma-separated list of sources to fetch (options: digiday, adexchanger, emarketer, wsj, nyt; default is digiday,adexchanger,emarketer,wsj,nyt).
    required: false
  interval:
    type: integer
    description: Interval in seconds for the scheduled task (default is 604800 / 7 days).
    required: false
---

# programmatic-news-fetch

This skill fetches, deduplicates, and compiles the latest programmatic advertising news articles from Digiday, AdExchanger, eMarketer, Wall Street Journal (CMO Today), and New York Times (Media & Advertising) RSS feeds. It generates a beautiful Markdown report and a CSV file, and can optionally send a summary of the top articles to a Slack channel. It also supports scheduling itself to run automatically on macOS.

### Prerequisites

- Optional: `SLACK_CLIENT_ID` and `SLACK_REFRESH_TOKEN` in your `.env` file if you want to send notifications to Slack.

### Command to Execute

```bash
python3 .agents/skills/programmatic-news-fetch/scripts/fetch_news.py --days {days} --output-dir "{output-dir}" --slack-channel "{slack-channel}" {schedule} --sources "{sources}" --interval {interval}
```